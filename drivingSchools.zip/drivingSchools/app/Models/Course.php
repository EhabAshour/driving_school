<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Relations\BelongsTo;;

class Course extends Model
{
    use HasFactory;
    protected $table = "courses";

    protected $fillable = ["price","details","registration_end_date","registration_start_date","end_course","start_course","school_id"];

    public $timestamps = false;
    public function student_course(){
        return $this->hasMany('App\Models\StudentCourse','course_id','id');
    }
    public function schedule(){
        return $this->hasMany('App\Models\Schedule','course_id','id');
    }
    public function setStartCourseAttribute($value)
    {
        $this->attributes['start_course'] = Carbon::parse($value)->format('Y-m-d');
    }
    public function getStartCourseAttribute()
    {
         return Carbon::parse($this->attributes['start_course'])->format('Y-m-d');
    }

    public function setEndCourseAttribute($value)
    {
        $this->attributes['end_course'] = Carbon::parse($value)->format('Y-m-d');
    }
    public function getEndCourseAttribute()
    {
         return Carbon::parse($this->attributes['end_course'])->format('Y-m-d');
    }

    public function setRegistrationStartDateAttribute($value)
    {
        $this->attributes['registration_start_date'] = Carbon::parse($value)->format('Y-m-d');
    }
    public function getRegistrationStartDateAttribute()
    {
         return Carbon::parse($this->attributes['registration_start_date'])->format('Y-m-d');
    }

    public function setRegistrationEndDateAttribute($value)
    {
        $this->attributes['registration_end_date'] = Carbon::parse($value)->format('Y-m-d');
    }
    public function getRegistrationEndDateAttribute()
    {
         return Carbon::parse($this->attributes['registration_end_date'])->format('Y-m-d');
    }

    public function school()
    {
    return $this->belongsTo('App\Models\School');
    }
    public function final_result(){
        return $this->hasMany('App\Models\FinalResult','course_id','id');
    }
    public function set(){
        return $this->hasMany('App\Models\Set','course_id','id');
    }

    
}
