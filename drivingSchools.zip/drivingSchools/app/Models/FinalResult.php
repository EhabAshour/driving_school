<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FinalResult extends Model
{
    use HasFactory;
    protected $table = "final_results";

    protected $fillable = ["course_id","student_name","theoritical","practical","final_result"];

    public $timestamps = false;
    public function course()
    {
    return $this->belongsTo('App\Models\Course');
    }
}
