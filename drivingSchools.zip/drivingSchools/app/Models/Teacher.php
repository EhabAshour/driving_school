<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Teacher extends Model
{
    use HasFactory;

    protected $table = "teachers";

    protected $fillable = ["name","years_of_experience","age","gender"];

    public $timestamps = false;

    public function setNameAttribute($value)
    {
        $this->attributes['name'] = strtolower($value);
    }

    public function school()
    {
    return $this->belongsTo('App\Models\School');
    }
    public function set(){
        return $this->hasMany('App\Models\Set','teacher_id','id');
    }
}
