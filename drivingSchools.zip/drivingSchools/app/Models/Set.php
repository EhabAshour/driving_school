<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Set extends Model
{
    use HasFactory;

    protected $table = "sets";

    protected $fillable = ["course_id","teacher_id","student_course_id","date","start_time","end_time"];

    public $timestamps = false;

    public function setDateAttribute($value)
    {
        $this->attributes['date'] = Carbon::parse($value)->format('Y-m-d');
    }
    public function getDateAttribute()
    {
         return Carbon::parse($this->attributes['date'])->format('Y-m-d');
    }

    public function teacher()
    {
    return $this->belongsTo('App\Models\Teacher');
    }
    public function course()
    {
    return $this->belongsTo('App\Models\course');
    }
    public function student_course()
    {
    return $this->belongsTo('App\Models\StudentCourse');
    }
}
