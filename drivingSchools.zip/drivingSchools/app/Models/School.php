<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Relations\HasMany;

class School extends Model
{
    use HasFactory, HasApiTokens;

    protected $table = "schools";

    protected $fillable = ["name","email","password","about","location","city"];

    public $timestamps = false;

    public function setNameAttribute($value)
    {
        $this->attributes['name'] = strtolower($value);
    }

    public function teacher(){
        return $this->hasMany('App\Models\Teacher','school_id','id');
    }
    public function course(){
        return $this->hasMany('App\Models\Course','school_id','id');
    }
}
