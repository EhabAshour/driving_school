<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Teacher;

class TeacherController extends Controller
{
    public function createTeacher(Request $request){
        $school_id = auth()->user()->id;
        // validation
    
        $request->validate([
            "name" => "required",
            "age" => "required",
            "years_of_experience" => "required",
            "gender" => "required",
        ]);

        // create data
        $teacher = new Teacher();

        $teacher->name = $request->name;
        $teacher->age = $request->age;
        $teacher->years_of_experience = $request->years_of_experience;
        $teacher->gender = $request->gender;
        $teacher->school_id = $school_id;

        $teacher->save();

        // send response
        return response()->json([
            "status" => 1,
            "message" => "Teacher added successfuly" 
        ]);
    }

    public function listTeachersForStudent($school_id){//for student
        $ins = Teacher::where('school_id',$school_id)->get();

        return response()->json([
            "status" => 1,
            "message" => "Listing Teachers: ",
            "data" => $ins
        ],200);
    }
    public function listTeachers(){//for school
        $school_id = auth()->user()->id;

        $teachers = Teacher::with('school')->where('school_id',$school_id)->get();
        foreach($teachers as $teacher){
            unset($teacher->school['password']);
            unset($teacher->school['created_at']);
            unset($teacher->school['updated_at']);
        }
        return response()->json([
            "status" => 1,
            "message" => "Listing Teachers: ",
            "data" => $teachers
        ],200);
    }

    public function getSingleTeacher($id){
        if(Teacher::where("id", $id)->exists()){
            $teacher = Teacher::with('school')->where("id", $id)->first();
            unset($teacher->school['password']);
            unset($teacher->school['created_at']);
            unset($teacher->school['updated_at']);
            return response()->json([
                "status" => 1,
                "message" => "Teacher found ",
                "data" => $teacher
            ],200);
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Teacher not found"
            ],404);
        }
    }
    
    public function deleteTeacher($id){
        if(Teacher::where("id", $id)->exists()){
            $ins = Teacher::find($id);
            try{
                $ins->delete();
            }catch(Throwable $th){
                return response()->json([
                    "status" => 0,
                    "message" => "can't delete this Teacher"
                    ],404); 
            }
            return response()->json([
                "status" => 1,
                "message" => "Teacher deleted successfully "
            ],200);
    
                
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Teacher not found"
                ],404);
        }
    
    }

    public function editTeacher(Request $request, $id){
        $school_id = auth()->user()->id;

        if(Teacher::where("id", $id)->where("school_id", $school_id)->exists()){
           
            $teacher = Teacher::find($id);
            $teacher->name = !empty($request->name)? $request->name : $teacher->name;
            $teacher->age = !empty($request->age)? $request->age : $teacher->age;
            $teacher->years_of_experience = !empty($request->years_of_experience)? $request->years_of_experience : $teacher->years_of_experience;
            $teacher->gender = !empty($request->gender)? $request->gender : $teacher->gender;

            $teacher->save();
            return response()->json([
                "status" => 1,
                "message" => "Teacher updated successfully "
            ],200);
            
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Teacher not found"
            ],404);
        }
        
        
    }
}
