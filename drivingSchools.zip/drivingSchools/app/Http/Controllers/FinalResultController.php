<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinalResult;
use Carbon\Carbon;

class FinalResultController extends Controller
{
    //

    public function createFinalResult(Request $request){
        $school_id = auth()->user()->id;
        // validation
    
        $request->validate([
            "course_id" => "required",
            "student_name" => "required",
            "theoritical" => "required",
            "practical" => "required",
           
        ]);

        // create data
        $final = new FinalResult();

        $final->course_id = $request->course_id;
        $final->student_name = $request->student_name;
        $final->theoritical = $request->theoritical;
        $final->practical = $request->practical;
        
        if($final->theoritical <50 ||$final->practical <50){
            $final->final_result = "fail";
        }
        else{$final->final_result = "pass";}
        

        $final->save();

        // send response
        return response()->json([
            "status" => 1,
            "message" => "Final Result added successfuly" 
        ]);
    }

    public function listFinalResults($course_id){//for school
        if(FinalResult::where("course_id", $course_id)->exists()){
            $ins = FinalResult::with('course')
            ->where("course_id", $course_id)->get();
    
            return response()->json([
                "status" => 1,
                "message" => "Listing final results: ",
                "data" => $ins
            ],200);
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Final Results not available yet!"
            ],404);
        }
    }

    public function getSingleFinalResult($id){
        if(FinalResult::where("id", $id)->exists()){
            $ins_details = FinalResult::with('course')->where("id", $id)->first();
           
            return response()->json([
                "status" => 1,
                "message" => "Final Result found ",
                "data" => $ins_details
            ],200);
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Final Result not found"
            ],404);
        }
    }
    
    public function deleteFinalResult($id){
        if(FinalResult::where("id", $id)->exists()){
            $ins = FinalResult::find($id);
            try{
                $ins->delete();
            }catch(Throwable $th){
                return response()->json([
                    "status" => 0,
                    "message" => "can't delete this Final Result"
                    ],404); 
            }
            return response()->json([
                "status" => 1,
                "message" => "Final Result deleted successfully "
            ],200);
    
                
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Final Result not found"
                ],404);
        }
    
    }

    public function editFinalResult(Request $request, $id){

        if(FinalResult::where("id", $id)->exists()){
           
            $final = FinalResult::find($id);
            $final->course_id = !empty($request->course_id)? $request->course_id : $final->course_id;
            $final->student_name = !empty($request->student_name)? $request->student_name : $final->student_name;

            
            $final->theoritical = !empty($request->theoritical)? $request->theoritical : $final->theoritical;
            $final->practical = !empty($request->practical)? $request->practical : $final->practical;
            
            
            if($final->theoritical <50 ||$final->practical <50){
                $final->final_result = "fail";
            }
            else{$final->final_result = "pass";}
            $final->save();

        // send response
        return response()->json([
            "status" => 1,
            "message" => "Final Result updated successfuly" 
        ]);
            
    
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Final Result not found"
            ],404);
        }
        
        
    }

    public function searchByName($search){
    
       
        if(FinalResult::where("student_name", "like", "%".$search."%"
        )
        ->exists()){
           
            $details = FinalResult::with('course')->where("student_name", "like", "%".$search."%")
            ->get();
            return response()->json([
                "status" => 1,
                "message" => "Final Result found ",
                "data" => $details
            ],200);
            }else{
                return response()->json([
                    "status" => 0,
                    "message" => "Final Result not found"
                ],404);
            }
        
    }
}
