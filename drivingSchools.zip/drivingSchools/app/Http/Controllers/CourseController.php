<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\StudentCourse;
use Carbon\Carbon;


class CourseController extends Controller
{
    //
    public function createCourse(Request $request){
        $school_id = auth()->user()->id;
        // validation
    
        $request->validate([
            "price" => "required",
            "details" => "required",
            "registration_end_date" => "required",
            "registration_start_date" => "required",
            "end_course" => "required",
            "start_course" => "required",
        ]);

        // create data
        $course = new Course();

        $course->price = $request->price;
        $course->details = $request->details;
        $course->school_id = $school_id;

        $start_date=Carbon::parse($request->start_date);
        $end_date=Carbon::parse($request->end_date);
        $start_reg=Carbon::parse($request->registration_start_date);
        $end_reg=Carbon::parse($request->registration_end_date);
        $today=Carbon::today();
        // echo $date3;
        

        if($start_date->lt($today)||$start_reg->lt($today)||
        $end_date->lt($start_date)||$end_reg->lt($start_reg)
        ||$start_date->gt($end_reg)
        ){
                return response()->json([
                    "status" => 1,
                    "message" => "Invalid date value!"
                ]); 
            }



        $course->registration_end_date = $request->registration_end_date;
        $course->registration_start_date = $request->registration_start_date;
        $course->start_course = $request->start_course;
        $course->end_course = $request->end_course;

        $course->save();

        // send response
        return response()->json([
            "status" => 1,
            "message" => "Course added successfuly" 
        ]);
    }

    public function listCoursesForStudent($school_id){//for student
        
        if(Course::where('school_id',$school_id)->exists()){
        $courses = Course::with('school')->where('school_id',$school_id)->get();
        
        foreach($courses as $course){
            unset($course->school['password']);
            unset($course->school['created_at']);
            unset($course->school['updated_at']);
        }
        return response()->json([
            "status" => 1,
            "message" => "Listing Courses: ",
            "data" => $courses
        ],200);
        }
        else{
            return response()->json([
                "status" => 0,
                "message" => "no available courses!"
            ],404);
        }
    }

    public function listCourses(){//for school
        $school_id = auth()->user()->id;

        if(Course::where('school_id',$school_id)->exists()){

        $courses = Course::with('school')->where('school_id',$school_id)->get();
        
        foreach($courses as $course){
            unset($course->school['password']);
            unset($course->school['created_at']);
            unset($course->school['updated_at']);
        }

        return response()->json([
            "status" => 1,
            "message" => "Listing Courses: ",
            "data" => $courses
        ],200);
    }else{
        return response()->json([
            "status" => 0,
            "message" => "Course not found!"
        ],404);
    }
    }

    public function getSingleCourse($id){
        if(Course::where("id", $id)->exists()){
            $course = Course::with('school')->where("id", $id)->first();
            $registered_students = StudentCourse::where('course_id',$course->id)->count();
            $course->students_number = $registered_students;
            unset($course->school['password']);
            unset($course->school['created_at']);
            unset($course->school['updated_at']);
            return response()->json([
                "status" => 1,
                "message" => "Course found ",
                "data" => $course
            ],200);
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Course not found"
            ],404);
        }
    }
    
    public function deleteCourse($id){
        if(Course::where("id", $id)->exists()){
            $ins = Course::find($id);
            try{
                $ins->delete();
            }catch(Throwable $th){
                return response()->json([
                    "status" => 0,
                    "message" => "can't delete this Course"
                    ],404); 
            }
            return response()->json([
                "status" => 1,
                "message" => "Course deleted successfully "
            ],200);
    
                
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Course not found"
                ],404);
        }
    
    }

    public function editCourse(Request $request, $id){
        $school_id = auth()->user()->id;

        if(Course::where("id", $id)->where("school_id", $school_id)->exists()){
           
            $course = Course::find($id);
            $course->price = !empty($request->price)? $request->price : $course->price;
            $course->details = !empty($request->details)? $request->details : $course->details;

            
            $course->start_course = !empty($request->start_course)? $request->start_course : $course->start_course;
            $course->end_course = !empty($request->end_course)? $request->end_course : $course->end_course;
            $course->registration_start_date = !empty($request->registration_start_date)? $request->registration_start_date : $course->registration_start_date;
            $course->registration_end_date = !empty($request->registration_end_date)? $request->registration_end_date : $course->registration_end_date;

            $start_date=Carbon::parse($course->start_date);
            $end_date=Carbon::parse($course->end_date);
            $start_reg=Carbon::parse($course->registration_start_date);
            $end_reg=Carbon::parse($course->registration_end_date);
            $today=Carbon::today();
            if($start_date->lt($today)||$start_reg->lt($today)||
            $end_date->lt($start_date)||$end_reg->lt($start_reg)){
                return response()->json([
                    "status" => 1,
                    "message" => "Invalid date value!"
                ]); 
            }
            $course->save();
            return response()->json([
                "status" => 1,
                "message" => "Course updated successfully "
            ],200);
            
        }else{
            return response()->json([
                "status" => 0,
                "message" => "Course not found"
            ],404);
        }
        
        
    }
}
