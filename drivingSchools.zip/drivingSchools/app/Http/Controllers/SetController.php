<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Set;
use App\Models\Course;
use App\Models\StudentCourse;
use Carbon\Carbon;



class SetController extends Controller
{
    //
    public function createSet(Request $request,$id){
        // validation
        $request->validate([
            // "insurance_type_id" => "required",
            "date" => "required",
            "start_time" => "required",
            "end_time" => "required",
            "teacher_id" => "required",
            "type" => "required"
        ]);
        $time=Carbon::now();
        //validate date*******************
        $start_date = Course::where('id',$id)->get('start_course');
        // echo $reg_start_date;
        $end_date = Course::where('id',$id)->get('end_course');
        // echo $reg_end_date;
        if ($request->date>=$time ){
            $start_date = $start_date->value('start_course');//createFromFormat
            // echo $reg_start_date;
            $end_date = $end_date->value('end_course');//createFromFormat
            // echo $reg_end_date;
    
            if($request->date>= $start_date && $request->date<= $end_date){
            $set = new Set();
            $set->course_id =$id;// $request->$insurance_type_id;
            $set->date = $request->date;
            $set->type = $request->type;
            $set->teacher_id = $request->teacher_id;

            if($request->start_time <$request->end_time){
                $set->start_time = $request->start_time;
                $set->end_time = $request->end_time;
        
                $set->save();
                 // send response
            return response()->json([
                "status" => 1,
                "message" => " course set created successfuly" 
            ]);
            }else{
                return response()->json([
                    "status" => 1,
                    "message" => "invalid time value!" 
                ],404);
            }
           
    
            
    
           
        }else{
            
            return response()->json([
                "status" => 1,
                "message" => "date must be between $start_date and $end_date" 
            ],404);
        }}}
    public function listTeachersInCourse($course_id){
        // $user = auth()->user()->id;
        $sets = Set::with('teacher')->where('course_id',$course_id)->get();
        $list = [];
        foreach($sets as $set){
           
            array_push($list,$set->teacher) ;

        }
            
        
        return response()->json([
            "status" => 1,
            "message" => "Listing Course teachers: ",
            "data" => $list
        ],200);
    }

    public function listAvailableSets($course_id){
        // $user = auth()->user()->id;
        if(Set::where('course_id',$course_id)->exists()){
            $sets = Set::where('course_id',$course_id)//with('teacher','course')
            ->where('student_course_id',Null)->get();
    
            return response()->json([
                "status" => 1,
                "message" => "Listing Course sets: ",
                "data" => $sets
            ],200);
        }
        else{
            return response()->json([
                "status" => 1,
                "message" => "sets not found "
            ],404);
        }
       
    }
    public function listSetsByTeacher($course_id,$teacher_id){
        // $user = auth()->user()->id;
        if(Set::where('course_id',$course_id)->exists()){
            $sets = Set::with('teacher','course')->where('course_id',$course_id)//with('teacher','course')
            ->where('student_course_id',Null)->where('teacher_id',$teacher_id)->get();
    
            return response()->json([
                "status" => 1,
                "message" => "Listing Course sets: ",
                "data" => $sets
            ],200);
        }
        else{
            return response()->json([
                "status" => 1,
                "message" => "sets not found "
            ],404);
        }
       
    }
    public function chooseSet($set_id,$course_id){
        $user = auth()->user()->id;
        if(Set::where('id',$set_id)->where('course_id',$course_id)->where('student_course_id',Null)->exists()){
            $sets = Set::where('course_id',$course_id)->where('student_course_id','!=',Null)->get();
            $number = 0;
            foreach($sets as $s){
            $student_course = $s->student_course;

            if($student_course->student_id == $user)$number++;
                        }
            echo $number;
            if($number<4){
                $set = Set::where('id',$set_id)//with('teacher','course')
                ->where('student_course_id',Null)->first();
                $student_course = new StudentCourse();
                $student_course->student_id = $user;
                $student_course->course_id = $course_id;
    
                $student_course->save();
                echo $set->id;
                $set2 = Set::find($set->id);
                $set2->student_course_id = $student_course->id;
                
                $set2->save();
                return response()->json([
                    "status" => 1,
                    "message" => "Course sets added successfully! "
                ],200);
            }else{
                return response()->json([
                    "status" => 1,
                    "message" => "you can't choose another set, you have registered in 4 sets already! "
                ],404);
            }
           
        }
        else{
            return response()->json([
                "status" => 1,
                "message" => "set not found "
            ],404);
        }
       
    }
    public function listTakenSets($course_id){
        // $user = auth()->user()->id;
        if(Set::where('course_id',$course_id)->where('student_course_id','!=',Null)->exists()){
        $sets = Set::with('teacher','course','student_course')->where('course_id',$course_id)->where('student_course_id','!=',Null)->get();
       

            
        
        return response()->json([
            "status" => 1,
            "message" => "Listing Student Courses: ",
            "data" => $sets
        ],200);
    }
    else{
        return response()->json([
            "status" => 1,
            "message" => "sets not found "
        ],404);
    }
    }

    public function listStudentsSetChoicesForACourse($course_id){
        $user = auth()->user()->id;
        if(Set::where('course_id',$course_id)->where('student_course_id','!=',Null)->exists()){

        $sets = Set::with('teacher','course','student_course')
        ->where('course_id',$course_id)
        ->where('student_course_id','!=',Null)->get();
        $list = [];
        foreach($sets as $set){
            echo $set->student_course->student_id;
            if($set->student_course->student_id==$user){
                // echo " llllll";
                array_push($list,$set) ;
            }
        }

            
        
        return response()->json([
            "status" => 1,
            "message" => "Listing Student Courses: ",
            "data" => $list
        ],200);
    }
    else{
        return response()->json([
            "status" => 1,
            "message" => "sets not found "
        ],404);
    }
    }

    public function getSingleSet($id){
        if(Set::where("id", $id)->exists()){
            $set_details = Set::with('teacher','course')->where("id", $id)->first();
           
            return response()->json([
                "status" => 1,
                "message" => "set found ",
                "data" => $set_details
            ],200);
        }else{
            return response()->json([
                "status" => 0,
                "message" => "set not found"
            ],404);
        }
    }

    public function deleteSet($id){
        if(Set::where("id", $id)->exists()){
            $set = Set::find($id);
            if($set->student_course ==Null){
                $set->delete();
                return response()->json([
                    "status" => 1,
                    "message" => "Set deleted successfully "
                ],200);
            }else{
                return response()->json([
                    "status" => 0,
                    "message" => "can't delete this set"
                    ],404); 
            
            }
            
        }   
            else{
            return response()->json([
                "status" => 0,
                "message" => "Set not found"
                ],404);
        }
    
    }
}
